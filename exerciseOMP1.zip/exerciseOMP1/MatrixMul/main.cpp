#include <chrono>
#include <iostream>     // std::cout, std::fixed
#include <random>
#include "MatrixMultiplication.hpp"
#include "Timer.hpp"
#include <omp.h>

int main() {
    using namespace timer;
    // -------------------- Matrix Allocation ----------------------------------
    
    /*  C++ 11 Style
    auto A = new int[ROWS][COLS];
    auto B = new int[ROWS][COLS];
    auto C = new int[ROWS][COLS];*/

    /*Memory is allocated for two matrices A and B of dimensions ROWS x COLS, 
    and two result matrices C_seq and C_par.*/
    int** A = new int*[ROWS];
    int** B = new int*[ROWS];
    int** C_seq = new int*[ROWS];
    int** C_par = new int*[ROWS];
    for (int i = 0; i < ROWS; i++) {
        A[i] = new int[COLS];
        B[i] = new int[COLS];
        C_seq[i] = new int[COLS];
        C_par[i] = new int[COLS];
        
    }
    // -------------------- Matrix Filling -------------------------------------
    /*    Random numbers are generated using a std::default_random_engine and a
    std::uniform_int_distribution with values between 1 and 100.
    These random numbers are used to fill the matrices A and B.*/
    std::cout << std::endl << "Matrix Filling...";

    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine generator (seed);
    std::uniform_int_distribution<int> distribution(1, 100);

    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j)
            A[i][j] = distribution(generator);
    }
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j)
            B[i][j] = distribution(generator);
    }
    
    std::cout << "done!" << std::endl;

    // =========================================================================
    // ----------------- Matrix Multiplication Sequential ----------------------
    /*The function sequentialMatrixMatrixMul(A, B, C_seq) performs the matrix multiplication sequentially.
    This involves nested loops to calculate each element of the resulting matrix C_seq.*/
    std::cout << std::endl << "Starting Sequential Mult....";
    Timer<HOST> TM_seq;
    Timer<HOST> TM_par;
    
    TM_seq.start();

    sequentialMatrixMatrixMul(A, B, C_seq);

    TM_seq.stop();
    std::cout << "done!" << std::endl<< std::endl;
    TM_seq.print("Sequential Matrix-Matrix Multiplication");

    // ----------------- Matrix Multiplication OPENMP --------------------------
    /*The function openmpMatrixMatrixMul(A, B, C_par) performs the matrix multiplication using OpenMP. 
    This involves the #pragma omp parallel for directive,
    which splits the iterations of the outer loop among the available threads.*/

    std::cout << std::endl << "Starting Parallel Mult....";
    TM_par.start();

    openmpMatrixMatrixMul(A, B, C_par);

    TM_par.stop();
    std::cout << "done!" << std::endl<< std::endl;
    TM_par.print("OpenMP Matrix-Matrix Multiplication");
    
    
    // ------------ Speedup: --------------------------------------------
    /*The program measures the duration of the sequential and parallel multiplications and calculates the speedup. 
    Speedup is defined as the ratio of the duration of the sequential computation to the duration of the parallel computation.*/
    std::cout << "Max threads: " << omp_get_max_threads() << std::endl;
    std::cout << std::setprecision(1)
    << "Speedup: " << TM_seq.duration() / TM_par.duration()
    << "x\n\n";
    
    
    // =========================================================================
    // ----------------- Check the results (C_seq = C_par) ----------------------
    /*Finally, the program checks if the results obtained from the sequential and parallel multiplications are the same. 
    If there is any discrepancy, the program will output an error message ERROR in Checking!. Otherwise, it will indicate that the check OK!.*/
    int error=0;
    for (int i = 0; i < ROWS; ++i) {
        for (int j = 0; j < COLS; ++j)
            if (C_seq[i][j] != C_par[i][j]){
                error=1;
                break;
            }
    }
    if(error)
        std::cout << std::endl <<"ERROR in Checking!" << std::endl<< std::endl;
    else
        std::cout << std::endl <<"Check OK!" << std::endl<< std::endl;
    
    
}