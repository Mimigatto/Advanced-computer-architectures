#!/bin/bash
DIR=`dirname $0`


g++ -O0 -std=c++11 -fopenmp "$DIR"/RC4.cpp -I"$DIR"/include/ -o rc4_O0
./rc4_O0


#g++-9 -O3 -std=c++11 -fopenmp "$DIR"/RC4.cpp -I"$DIR"/include/ -o rc4_O3
#./rc4_O3
