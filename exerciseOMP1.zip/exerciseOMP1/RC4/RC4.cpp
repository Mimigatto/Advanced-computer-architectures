#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <omp.h>
#include <unistd.h>
#include "Timer.hpp"
/*This code appears to be an implementation of a stream cipher called RC4 (Rivest Cipher 4)
along with a brute force key recovery attempt using both sequential and parallel execution.*/
/*The code includes several C++ libraries for various functionalities, including algorithm, memory management, input/output, timing, and parallel processing.
It defines two functions for RC4 encryption:*/

//key_scheduling_alg: Initializes the RC4 state array (S) based on the given key.
void key_scheduling_alg(unsigned char*       S,
                        const unsigned char* key,
                        const int            key_length) {
    for (int i = 0; i < 256; ++i)
        S[i] = i;
    int j = 0;
    for (int i = 0; i < 256; ++i) {
        j = (j + S[i] + key[i % key_length]) % 256;
        std::swap(S[i], S[j]);
    }
}
//pseudo_random_gen: Generates a stream of pseudo-random bytes based on the RC4 state array (S)
void pseudo_random_gen(unsigned char* S,
                       unsigned char* stream,
                       int            input_length) {
    for (int x = 0; x < input_length; ++x) {
        int i = (i + 1) % 256;
        int j = (j + S[i]) % 256;
        std::swap(S[i], S[j]);
        stream[x] = S[(S[i] + S[j]) % 256];
    }
}
//The chech_hex function is used to check whether the generated ciphertext matches the expected ciphertext.
bool chech_hex(const unsigned char* cipher_text,
              const unsigned char* stream,
              const int            key_length) {
    for (int i = 0; i < key_length; ++i) {
        if (cipher_text[i] != stream[i])
            return false;
    }
    return true;
}
//There are utility functions for printing hexadecimal representations of data
void print_hex(const unsigned char* text, const int length, const char* str) {
    std::cout << std::endl << std::left << std::setw(15) << str;
    for (int i = 0; i < length; ++i)
        std::cout << std::hex << std::uppercase << (int) text[i] << ' ';
    std::cout <<  std::dec << std::endl;
}
//Constants for bit length, key length, and some arrays for plaintext, ciphertext, and the key are defined.
const int bitLength  = 24;
const int key_length = bitLength / 8;

//The main function is the entry point of the program and is divided into two parts: sequential and parallel execution.
int main() {
    using namespace timer;

    unsigned char S[256],
    stream[key_length],
    key[key_length]         = {'K','e','y'},
    Plaintext[key_length]   = {'j','j','j'},
    cipher_text[key_length] = {0xB, 0xC7, 0x85};

    print_hex(Plaintext, key_length, "Plaintext:");
    print_hex(cipher_text, key_length, "cipher_text:");
    print_hex(key, key_length, "Key:");


    //sequential//
    // -------------------------------------------------------------------------
    /*It starts a timer to measure the execution time.
It initializes the RC4 state array S with the key provided.
Generates a pseudo-random stream using the key and pseudo_random_gen.
XORs the generated stream with the plaintext to obtain the ciphertext.
Checks if the generated ciphertext matches the expected ciphertext and prints "check ok!" if it does.
Enters a loop to attempt to crack the key using brute force. It iterates through all possible keys within the specified bit length.
Checks if the generated ciphertext matches the expected ciphertext for each key. If a match is found, it prints "<> CORRECT" and sets find to true.
The loop increments the key to try the next possible value.
If the key is not found, it prints "ERROR!! key not found."
The timer is stopped and the time taken for sequential execution is printed.*/
    Timer<HOST> TM;
    TM.start();

    std::cout << "Sequential Execution\n";
    key_scheduling_alg(S, key, key_length);
    pseudo_random_gen(S, stream, key_length);

    print_hex(stream, key_length, "PRGA Stream:");

    for (int i = 0; i < key_length; ++i)
        stream[i] = stream[i] ^ Plaintext[i];        // XOR

    print_hex(stream, key_length, "XOR:");
    if (chech_hex(cipher_text, stream, key_length))
        std::cout << "check ok!\n";
    std::cout << "Cracking..." << std::endl;

    // --------------------- CRACKING ------------------------------------------

    std::fill(key, key + key_length, 0);

    bool find = false;
    for (int k = 0; k < (1<<24); ++k) {
        key_scheduling_alg(S, key, key_length);
        pseudo_random_gen(S, stream, key_length);

        for (int i = 0; i < key_length; ++i)
            stream[i] = stream[i] ^ Plaintext[i];        // XOR

        if (chech_hex(cipher_text, stream, key_length)) {
            std::cout << " <> CORRECT\n";
            find=true;
            break;
        }
        int next = 0;
        while (key[next] == 255) {
            key[next] = 0;
            ++next;
        }
        ++key[next];
    }
    if(!find){
        std::cout << "ERROR!! key not found\n";
    }
    TM.stop();
    TM.print("Sequential Time");
    //end sequential

    
    
    
    //start parallel
    /*The parallel execution section is almost identical to the sequential section, 
    with the main difference being the use of OpenMP to parallelize the key recovery loop.
A #pragma omp parallel for directive is used to parallelize the loop, allowing multiple threads to search for the key simultaneously.
The rest of the process, including initializing the state array,
generating the stream, XORing, and checking for the key, remains the same.
The timer is started and stopped for the parallel execution, and the time taken is printed.*/
    
    std::cout << "\nParallel Execution\n";
    TM.start();
    
    key_scheduling_alg(S, key, key_length);
    pseudo_random_gen(S, stream, key_length);

    print_hex(stream, key_length, "PRGA Stream:");

    for (int i = 0; i < key_length; ++i)
        stream[i] = stream[i] ^ Plaintext[i];        // XOR

    print_hex(stream, key_length, "XOR:");
    if (chech_hex(cipher_text, stream, key_length))
        std::cout << "check ok!\n";
    std::cout << "Cracking..." << std::endl;

    // --------------------- CRACKING ------------------------------------------


    std::fill(key, key + key_length, 0);

    find = false;

    #pragma omp parallel for 
    for (int k = 0; k < (1<<24); ++k) {
        if(!find){
            key_scheduling_alg(S, key, key_length);
            pseudo_random_gen(S, stream, key_length);
            
            for (int i = 0; i < key_length; ++i)
                stream[i] = stream[i] ^ Plaintext[i];        // XOR

            if (chech_hex(cipher_text, stream, key_length)) {
                std::cout << " <> CORRECT\n";
                find=true;
            }
            int next = 0;
            while (key[next] == 255) {
                key[next] = 0;
                ++next;
            }
            ++key[next];
        }
    }

    if(!find){
        std::cout << "ERROR!! key not found\n";
    }
    TM.stop();
    TM.print("Parallel Time");
    //end parallel
    return 0;
}
/*In summary, this code demonstrates the RC4 encryption algorithm with a key recovery attempt through brute force
using both sequential and parallel execution.The goal is to find the key that produces the expected ciphertext 
by testing all possible keys within the specified bit length.*/