#include <chrono>
#include <iostream>
#include <random>
#include <omp.h>
#include "Timer.hpp"
/*This code is an example of using OpenMP for parallel programming.
It compares the time taken by a sequential search algorithm with the time taken by its parallel counterpart.
It starts by initializing an integer array of size N (1 << 25) with random values.*/

int main() {
    using namespace timer;
    int N = (1 << 25);
    /*The program then creates a timer object to measure the time taken by the sequential search algorithm.
The sequential search algorithm is executed by iterating over the array and checking if each element matches the given pattern.*/
       
    int* Array = new int[N];
    const int to_find1 = 18;        //search [ .. ][ .. ][ 18 ][ 64 ][ .. ]
    const int to_find2 = 64;

    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::chrono::time_point<std::chrono::system_clock> start, end;
    std::default_random_engine generator (seed);
    std::uniform_int_distribution<int> distribution(1, 10000);

    /*Loop Boundaries: Your loop for both sequential and parallel searches goes up to N - 1,
which means it will not check the last element of the array. 
If you want to include the last element in the search, change the loop boundaries to i < N  */

        for (int i = 0; i < N; ++i)

        Array[i] = distribution(generator);

    // ------------ SEQUENTIAL SEARCH ------------------------------------------
    /*The program then creates a timer object to measure the time taken by the sequential search algorithm.*/

    Timer<HOST> TM_seq;
    Timer<HOST> TM_par;
     /*The sequential search algorithm is executed by iterating over the array and checking if each element matches the given pattern.*/
    
    TM_seq.start();

        /*Thread Safety:
You're using OpenMP to parallelize the search, and you've used the flag variable to control early exit from the loop.
While this approach works, it may not be very efficient, especially if there are many threads. 
A better way to control early exit from the loop is to use a #pragma omp cancel construct. 
You can set a cancellation point in your loop and then use #pragma omp cancellation to cancel the loop when the condition is met.
This approach can help improve efficiency when dealing with early exits in parallel loops.
Here's a modified version of your loop using #pragma omp cancellation
index = -1;
#pragma omp parallel for
for (int i = 0; i < N - 1; ++i) {
    #pragma omp cancellation point for
    if (Array[i] == to_find1 && Array[i + 1] == to_find2) {
        #pragma omp cancel for
        index = i;
    }
}
*/
    
    int index = -1;
        
    for (int i = 0; i < N - 1; ++i) {
        if (Array[i] == to_find1 && Array[i + 1] == to_find2) {
            index = i;
            break;            // !!! error in OPENMP
        }
    }


    TM_seq.stop();
/*After the sequential search, the program measures the time taken and prints it.
Next, the program creates a timer object to measure the time taken by the parallel search algorithm.*/
    TM_seq.print("Sequential Search");
    std::cout << index << std::endl;

    // ------------ PARALLEL SEARCH --------------------------------------------
    /*The parallel search algorithm is executed using the OpenMP directive '#pragma omp parallel for'.
    This directive instructs the compiler to generate code that runs
    the loop in parallel using multiple threads.*/
    TM_par.start();

    index = -1;
    bool flag = true;
    #pragma omp parallel for firstprivate(flag) shared(index)
    for (int i = 0; i < N - 1; ++i) {
        if (flag && Array[i] == to_find1 && Array[i + 1] == to_find2) {
            index = i;                        // index: concurrent value
            flag = false;
            /*Inside the parallel loop, the program checks if the current element matches the pattern.
            If a match is found, the program sets a flag to false and breaks out of the loop.*/
        }
    }

    TM_par.stop();
    //After the parallel search, the program measures the time taken and prints it.
    TM_par.print("Parallel Search");
    std::cout << index << std::endl;



// ------------ Speedup: --------------------------------------------
/*Finally, the program calculates the speedup by dividing the time taken
by the sequential search algorithm by the time taken by the parallel search algorithm.*/

std::cout << "Max threads: " << omp_get_max_threads() << std::endl;
std::cout << std::setprecision(1)
<< "Speedup: " << TM_seq.duration() / TM_par.duration()
<< "x\n\n";

//To avoid a memory leak, you should free this memory 
delete[] Array;

}
