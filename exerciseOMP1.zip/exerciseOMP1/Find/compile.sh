#!/bin/bash
DIR=`dirname $0`

g++ -O0 -std=c++11 -fopenmp "$DIR"/Find.cpp -I"$DIR"/include/ -o find_omp_O0
./find_omp_O0


g++ -O3 -std=c++11 -fopenmp "$DIR"/Find.cpp -I"$DIR"/include/ -o find_omp_O3
./find_omp_O3
