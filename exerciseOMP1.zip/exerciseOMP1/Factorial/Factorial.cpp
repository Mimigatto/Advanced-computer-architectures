
#include <iostream>
#include <omp.h>
//#include <Timer.h>

/*The first loop calculates the factorial sequentially. This is done by initializing a variable called 'factorial' to 1,
then multiplying it by each number from 1 to N. The duration of this calculation 
is measured using a Timer object and printed*/
int main() {
    using namespace timer;
    int N = (1 << 30);
    double factorial = 1;
    
    Timer<HOST> TM_seq;
    Timer<HOST> TM_par;
    
    
    TM_seq.start();
    
    for (int i = 1; i <= N; ++i)
        factorial *= i;
    
    TM_seq.stop();
    TM_seq.print("Sequential Factorial");
    std::cout << factorial << std::endl;
    
    /*Next, we initialize an array called 'results' to store the factorial calculated by each thread in the parallel section*/
    auto results = new double[omp_get_max_threads()]();
    TM_par.start();

    /*We use the OpenMP pragma '#pragma omp parallel' to enable parallelism in the following code block.
    This means that the code within this block will be executed by multiple threads simultaneously*/
#pragma omp parallel
    {
        int i;
        double ThFactorial = 1;
     
/* Within the parallel block, we initialize a variable called 'ThFactorial' to 1. Then, we use the '#pragma omp for'
directive to distribute the loop iterations among the available threads.*/

#pragma omp for //firstprivate(N) private(i)
        for (i = 1; i <= N; ++i)
            ThFactorial *= i;
        results[omp_get_thread_num()] = ThFactorial;
    }
//Each thread calculates its portion of the factorial and stores it in the 'results' array//        
    double parallelResult = 1;
    for (int i = 0; i < omp_get_max_threads(); ++i)
        parallelResult *= results[i];
 /*After all threads have finished their calculations, we initialize a variable called 'parallelResult' to 1.
 Then, we multiply 'parallelResult' by each element of the 'results' array to get the total factorial calculated by all threads*/
    TM_par.stop();
    TM_par.print("Parallel Factorial");
    std::cout << parallelResult << std::endl;
    
    // ------------ Speedup: --------------------------------------------
    /*Finally, we measure the duration of the parallel factorial calculation and print it. 
    We also calculate and print the speedup factor,which is the ratio of the
    duration of the sequential calculation to the duration of the parallel calculation.*/

    std::cout << "Max threads: " << omp_get_max_threads() << std::endl;
    std::cout << std::setprecision(1)
    << "Speedup: " << TM_seq.duration() / TM_par.duration()
    << "x\n\n";
     
    }
