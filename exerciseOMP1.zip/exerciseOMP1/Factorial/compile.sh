#!/bin/bash
DIR=`dirname $0`

# Compile the program with the desired options
g++ -O0 -std=c++11 -fopenmp "$DIR"/Factorial.cpp -I"$DIR"/include -o factorial_O0
# Set OMP_SCHEDULE environment variable before running the program
export OMP_SCHEDULE="dynamic,16"

# Run the program
./factorial_O0


# Optionally, you can set OMP_SCHEDULE for another build and run it
# export OMP_SCHEDULE="static,8"

