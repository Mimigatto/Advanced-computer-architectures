#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <omp.h>

void test_producer_consumer(int Buffer[32]) {
    int i = 0;
    int count = 0;
    omp_lock_t buffer_lock;  // Declare a lock for buffer access

    // Initialize the lock
    omp_init_lock(&buffer_lock);

    while (i < 35000) {
        // PRODUCER
        if ((std::rand() % 50) == 0) {
            if (count < 31) {
                // Use a critical region for count updates
                #pragma omp critical (CountUpdate)
                {
                    ++count;  // Atomically increment the count
                    printf("Thread:\t%d\tProduce on index: %d\n", omp_get_thread_num(), count);
                    Buffer[count] = omp_get_thread_num();  // Add to the buffer
                }
            }
        }

        // CONSUMER
        if ((std::rand() % 51) == 0) {
            if (count >= 1) {
                int var;
                // Use a lock for buffer access
                omp_set_lock(&buffer_lock);
                var = Buffer[count];  // Retrieve from the buffer
                --count;  // Atomically decrement the count
                omp_unset_lock(&buffer_lock);
                printf("Thread:\t%d\tConsume on index: %d\tvalue: %d\n", omp_get_thread_num(), count + 1, var);
            }
        }
        i++;
    }

    // Destroy the lock
    omp_destroy_lock(&buffer_lock);
}

int main() {
    int Buffer[32];
    std::srand(static_cast<unsigned int>(time(NULL));

    omp_set_dynamic(0);  // Disable dynamic thread adjustment
    omp_set_num_threads(2);

    #pragma omp parallel
    {
        test_producer_consumer(Buffer);
    }
}



/*QA: Potential Applications:

Mutex's Critical Region Locks and Atomic Operations:
This code uses locks to prevent unauthorized access
 to the shared buffer and a crucial region to manage 
 the "count" variable. The locks preserve buffer access
  while the critical region guarantees atomic changes of
   the "count" variable. The producer-consumer implementation
    is made more resilient by this combination.

Barriers:
In general, barriers are not applied to the
 producer-consumer issue. They are used to keep threads
 synchronized at particular code places.

Shared Variables Only:
 Data corruption and racial situations may arise from depending
 only on shared variables. Although it is generally not advised,
  it is theoretically feasible to execute it under extremely 
  rigorous and particular conditions. It is recommended to use explicit
   synchronization techniques to synchronize producer and consumer threads.*/
