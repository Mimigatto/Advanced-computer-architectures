#include <algorithm>
#include <chrono>
#include <iostream>
#include <random>
#include <omp.h> // OpenMP library for parallelism

// ---------- DO NOT MODIFY ----------------------------------------------------
// This is a helper function for the quicksort algorithm, used to partition the array.
int partition(int array[], const int start, const int end) {
    int p = start;
    int pivot_element = array[end];
    for (int i = start; i < end; i++) {
        if (array[i] < pivot_element) {
            std::swap(array[i], array[p]);
            ++p;
        }
    }
    std::swap(array[p], array[end]);
    return p;
}
//------------------------------------------------------------------------------

// Quick sort algorithm, which is a parallel implementation.
void quick_sort(int array[], const int start, const int end) {
    if (start < end) {
        int pivot = partition(array, start, end);

        // This pragma directive indicates that the following code should be executed as tasks in parallel.
        #pragma omp task
        quick_sort(array, start, pivot - 1);

        // This pragma directive indicates that the following code should be executed as tasks in parallel.
        #pragma omp task
        quick_sort(array, pivot + 1, end);
    }
}

// Template function to print an array of any data type.
template<typename T>
void print_array(T* array, int size, const char* str) {
    std::cout << str << "\n";
    for (int i = 0; i < size; ++i)
        std::cout << array[i] << ' ';
    std::cout << "\n" << std::endl;
}

int main() {
    const int N = 100;

    // Seed the random number generator
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::default_random_engine generator(seed);
    std::uniform_int_distribution<int> distribution(1, 100);

    // Create an array and fill it with random integers
    int* input = new int[N];
    for (int i = 0; i < N; ++i)
        input[i] = distribution(generator);

    // Print the original input array
    print_array(input, N, "\nInput:");

    #pragma omp parallel
    {
        #pragma omp single nowait
        {
            // This pragma directive indicates that the following code should be executed as a single task in parallel.
            #pragma omp task
            quick_sort(input, 0, N - 1);
        }
    }

    // Print the sorted array
    print_array(input, N, "Sorted:");

    // Clean up memory
    delete[] input;
    return 0;
}

