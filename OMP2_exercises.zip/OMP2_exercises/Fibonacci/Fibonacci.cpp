#include <iostream>
#include <omp.h>

long long int fibonacci(long long int value, int level) {
    if (value <= 1)
        return 1;

    long long int fib_left, fib_right;

    // Parallelize the computation of Fibonacci numbers at the previous two indices.
    #pragma omp task shared(fib_left)
    fib_left = fibonacci(value - 1, level + 1);

    // Create a task for the right part of the Fibonacci sequence.
    #pragma omp task shared(fib_right)
    fib_right = fibonacci(value - 2, level + 1);

    // Wait for the tasks to complete before returning the sum.
    #pragma omp taskwait

    return fib_left + fib_right;
}

int main() {
    // Initialize OpenMP by setting dynamic thread adjustment to false.
    omp_set_dynamic(0);

    int value = 5; // The top-level Fibonacci number you want to compute (level 1).

    double start_time = omp_get_wtime(); // Record the start time.

    long long int result = 0;

    // Enable OpenMP parallelism.
    #pragma omp parallel
    {
        #pragma omp single
        {
            long long int parallel_result = 0;

            // Create a task to calculate the top-level Fibonacci number.
            #pragma omp task shared(parallel_result)
            parallel_result = fibonacci(value, 1);

            // Wait for the task to complete before printing the result.
            #pragma omp taskwait

            std::cout << "result: " << parallel_result << std::endl;
        }
    }

    double end_time = omp_get_wtime(); // Record the end time.

    // Calculate and print the elapsed time for the parallel calculation.
    double elapsed_time = end_time - start_time;
    std::cout << "Parallel elapsed time: " << elapsed_time << " seconds" << std::endl;

    return 0;
}

/*QA:Is the parallel version worth it? When?
  ANS:: The parallel version of the code is worth it when:

1. You have a computationally intensive task that can be divided into smaller independent parts.
2. You have a multi-core CPU or a multi-processor system.
3. The overhead of task creation and synchronization is outweighed by the benefits of parallelism.

In cases like the Fibonacci sequence, which has a low computational load and high task creation overhead, 
the benefits of parallelism may be limited unless the workload is significantly larger.*/