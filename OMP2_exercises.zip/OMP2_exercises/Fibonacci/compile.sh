#!/bin/bash

# Set the directory of the script as the working directory
DIR=$(dirname "$0")
cd "$DIR"

# Source code file and output executable
SOURCE_FILE="Fibonacci.cpp"
EXECUTABLE="fibonacci"

# Check if the source file exists
if [ ! -f "$SOURCE_FILE" ]; then
    echo "Source file '$SOURCE_FILE' not found."
    exit 1
fi

# Compile the C++ program with g++
g++ -std=c++11 -fopenmp "$SOURCE_FILE" -o "$EXECUTABLE"

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "Compilation successful HIP HIP!!. Executable: $EXECUTABLE"
else
    echo "Compilation failed. Oops!!"
fi
